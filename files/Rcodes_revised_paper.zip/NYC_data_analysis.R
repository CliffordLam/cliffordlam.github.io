################### This script is used to analyse NYC Taxi Traffic data using tensor factor models #############################
library(arrow)
library(bizdays)
library(abind)
library(TensorPreAve)
source('supporting_functions.R')


# Read data

# bizdays
data_2011 = readRDS('bizday_2011.RData')
data_2012 = readRDS('bizday_2012.RData')
data_2013 = readRDS('bizday_2013.RData')
data_2014 = readRDS('bizday_2014.RData')
data_2015 = readRDS('bizday_2015.RData')
data_2016 = readRDS('bizday_2016.RData')
data_2017 = readRDS('bizday_2017.RData')
data_2018 = readRDS('bizday_2018.RData')
data_2019 = readRDS('bizday_2019.RData')
data_2020 = readRDS('bizday_2020.RData')
data_2021 = readRDS('bizday_2021.RData')

# nonbizdays
# data_2011 = readRDS('nonbizday_2011.RData')
# data_2012 = readRDS('nonbizday_2012.RData')
# data_2013 = readRDS('nonbizday_2013.RData')
# data_2014 = readRDS('nonbizday_2014.RData')
# data_2015 = readRDS('nonbizday_2015.RData')
# data_2016 = readRDS('nonbizday_2016.RData')
# data_2017 = readRDS('nonbizday_2017.RData')
# data_2018 = readRDS('nonbizday_2018.RData')
# data_2019 = readRDS('nonbizday_2019.RData')
# data_2020 = readRDS('nonbizday_2020.RData')
# data_2021 = readRDS('nonbizday_2021.RData')

data = abind(data_2011,data_2012,data_2013,data_2014,data_2015,data_2016,data_2017,data_2018,data_2019,data_2020,data_2021,along = 1)

## Zone index 19,20,21 has very few data (even 0), and should be ignored when doing analysis
data = data[,-c(19,20,21),-c(19,20,21),]

X = as.tensor(data)


### Estimate the rank of core tensors
set.seed(2023)
Q_pre = pre_est(X,z = c(1,1,1))
Q_proj = iter_proj(X,Q_pre, z = c(1,1,1))
BCorTh_rank = bs_cor_rank(X,Q_proj, B = 10)
print(BCorTh_rank)


# Other competitors:
d = X@modes[-1]
## RTFA-ER
set.seed(1)
HOSVD_estimator = HOSVD(X,z = floor(d/2))
RT_factor_rank = robust_tensor_factor_ER(X, proj_N = 30, INIT_Q = HOSVD_estimator)
print(RT_factor_rank[['r_hat']])

## PE-ER
set.seed(1)
HOSVD_estimator = HOSVD(X,z = floor(d/2))
HOOI_factor_rank = HOOI_ER(X, proj_N = 30, HOSVD_estimator)
print(HOOI_factor_rank[['r_hat']])

## iTIPUP-ER
set.seed(1)
TIPUP_result = TIPUP_ER(X, h0 = 1, ER_c = 0.1)
TIPUP_estimator = TIPUP_result[['TIPUP_estimator']]
TIPUP_rank = TIPUP_result[['ER']]
iTIP_ER_rank = iTIPUP_ER(X, h0 = 1, proj_N = 30, INIT_Q = TIPUP_estimator,initial_rank_estimator = TIPUP_rank, ER_c = 0.1)
print(iTIP_ER_rank)




### Estimate the factor loading matrices
set.seed(2023)
Q_pre = pre_est(X,z = c(1,1,1))
Q_proj = iter_proj(X,Q_pre, z = c(3,3,2))
# # varimax rotation for better representation
# round(varimax(Q_proj[[3]])$loadings * 30, 3)







