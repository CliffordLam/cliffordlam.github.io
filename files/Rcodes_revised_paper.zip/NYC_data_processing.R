################### This script is used to pre-process NYC Taxi Traffic data #############################
library(arrow)
library(bizdays)
library(abind)

business_calendar = create.calendar('my_calendar', weekdays = c('saturday','sunday'),
                                    holidays = timeDate::holidayNYSE(2011:2021))

## predefined zones for Manhattan
Man = c(4,
        12,
        13,
        24,
        41,
        42,
        43,
        45,
        48,
        50,
        68,
        74,
        75,
        79,
        87,
        88,
        90,
        100,
        103,
        104,
        105,
        107,
        113,
        114,
        116,
        120,
        125,
        127,
        128,
        137,
        140,
        141,
        142,
        143,
        144,
        148,
        151,
        152,
        153,
        158,
        161,
        162,
        163,
        164,
        166,
        170,
        186,
        194,
        202,
        209,
        211,
        224,
        229,
        230,
        231,
        232,
        233,
        234,
        236,
        237,
        238,
        239,
        243,
        244,
        246,
        249,
        261,
        262,
        263)




bizday_year_tensor = array(NA, c(0,69,69,24))
nonbizday_year_tensor = array(NA, c(0,69,69,24))

all_months = c("01",'02','03','04','05','06','07','08','09','10','11','12')


## Process NYC Taxi Traffic data for each year

year = '2011' # change this for different years

start_time = Sys.time()

## Process data for each month
for (m in 1:12)
{

  print(m)
  each_start_time = Sys.time()
  data_each_month = read_parquet(paste(paste(paste("yellow_tripdata",year,sep="_"),all_months[m],sep='-'), '.parquet',sep = ''))
  data_each_month = data_each_month[,c("tpep_pickup_datetime","PULocationID","DOLocationID")]

  # Only consider rides within Manhattan Island
  data = data_each_month[data_each_month[,"PULocationID"] %in% Man & data_each_month[,"DOLocationID"] %in% Man,]

  # Convert date and time to specific format
  data[,"date"] = as.Date(data[,"tpep_pickup_datetime"])
  data[,"time"] = as.integer(strftime(data[,"tpep_pickup_datetime"], format="%H"))


  ## create the target tensor
  dates_in_each_month = unique(data[,"date"])

  # deal with some error dates
  true_month = names(which.max(table(format(as.Date(dates_in_each_month), "%Y-%m"))))
  dates_in_each_month = dates_in_each_month[format(as.Date(dates_in_each_month), "%Y-%m") == true_month]


  biz_each_month = bizseq(sort(dates_in_each_month)[1],sort(dates_in_each_month)[length(dates_in_each_month)], business_calendar)
  nonbiz_each_month = dates_in_each_month[!(dates_in_each_month %in% biz_each_month)]

  ## Process data for each day
  bizday_tensor = array(NA,c(length(biz_each_month),69,69,24))
  nonbizday_tensor = array(NA,c(length(nonbiz_each_month),69,69,24))

  ## tensor for biz days
  for (d in 1:length(biz_each_month))
  {
    data_each_day = data[data[,"date"] == biz_each_month[d],]

    for (h in 0:23)
    {
      data_each_hour = data_each_day[data_each_day[,"time"] == h,]
      count = matrix(NA,length(Man),length(Man))
      for (i in 1:length(Man))
      {
        for (j in 1:length(Man))
        {
          count[i,j] = sum(data_each_hour[,"PULocationID"] == Man[i] & data_each_hour[,"DOLocationID"] == Man[j])
        }
      }
      bizday_tensor[d,,,h+1] = count
    }
  }

  ## tensor for nonbiz days
  for (d in 1:length(nonbiz_each_month))
  {
    data_each_day = data[data[,"date"] == nonbiz_each_month[d],]

    for (h in 0:23)
    {
      data_each_hour = data_each_day[data_each_day[,"time"] == h,]
      count = matrix(NA,length(Man),length(Man))
      for (i in 1:length(Man))
      {
        for (j in 1:length(Man))
        {
          count[i,j] = sum(data_each_hour[,"PULocationID"] == Man[i] & data_each_hour[,"DOLocationID"] == Man[j])
        }
      }
      nonbizday_tensor[d,,,h+1] = count
    }
  }



  bizday_year_tensor = abind(bizday_year_tensor, bizday_tensor,along = 1)
  nonbizday_year_tensor = abind(nonbizday_year_tensor, nonbizday_tensor,along = 1)

  each_end_time = Sys.time()
  print(each_end_time - each_start_time)
}

end_time = Sys.time()

print(end_time - start_time)

sum(bizday_year_tensor)
sum(nonbizday_year_tensor)
dim(bizday_year_tensor)
dim(nonbizday_year_tensor)

## save the data
saveRDS(bizday_year_tensor, file = paste(paste("bizday",year,sep="_"),".RData",sep = ''))
saveRDS(nonbizday_year_tensor, file = paste(paste("nonbizday",year,sep="_"),".RData",sep = ''))





