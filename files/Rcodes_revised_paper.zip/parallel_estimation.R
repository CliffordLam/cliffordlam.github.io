##################################### This script is for estimation of simulation experiments #############################
###### It reads the generated data, estimate the factor loading spaces and rank of the core tensors

library(MASS)
library(pracma)
library(rTensor)
library(TensorPreAve)
source("supporting_functions.R")

library(doSNOW)
library(parallel)

# ncore = detectCores()     # The number of cores to use for parallel computing
ncore = 6



### Change settings (i) to (v) for data generation under different dimensions

# (i)
K = 2                     # The number of modes for the tensor time series
T = 100                   # Length of time series
d = c(40,40)              # Dimensions of each mode of the tensor

# # (ii)
# K = 2
# T = 200
# d = c(80,80)
#
# # (iii)
# K = 3
# T = 200
# d = c(15,15,15)
#
# # (iv)
# K = 3
# T = 200
# d = c(25,25,25)
#
# # (v)
# K = 4
# T = 200
# d = c(15,15,15,15)


r = rep(2,K)                # Rank of core tensors
re = rep(2,K)               # Rank of the cross-sectional common error core tensors


## We run parallel computing to do estimation of all 12 profiles of each dimension
eta_list = list(rep(list(c(0,0)),K),                      # Setting (I)
                rep(list(c(0,0.2)),K),                    # Setting (II)
                rep(list(c(0.1,0.2)),K))                  # Setting (III)

u_list <- list(rep(list(c(-2,2)),K),                      # Sub-setting (a)
               rep(list(c(0,0,2)),K))                     # Sub-setting (b)

heavy_tail_list = c(rep(FALSE,6),rep(TRUE,6))


eta_total <- rep(eta_list, 4)
u_total <- rep(u_list,6)


cl <- makeCluster(ncore)
registerDoSNOW(cl)
pb <- txtProgressBar(max = 12, style = 3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress = progress)
t111 <- Sys.time()
# start parallel computing
sim11 <- foreach(j = 1:12, .options.snow = opts) %dopar% {

  eta <- eta_total[[j]]
  u <- u_total[[j]]
  heavy_tail = heavy_tail_list[j]



  para_list = list(
    'K' = K,
    'T' = T,
    'd' = d,
    'r' = r,
    're' = re,
    'eta' = eta,
    'u' = u)
  file_name = paste(names(para_list),para_list,sep="=",collapse="_")

  if (heavy_tail)
  {
    file_name = paste(file_name,'t3',sep = '_')
  }


  data_file_name = paste(file_name, 'Data',sep = '_')
  Data_read = readRDS(file = paste(data_file_name,'.RData',sep = ''))



  ##### Estimation of factor loading spaces #####

  N = 500

  # Create matrices which stores the result
  result_PRE_200_space = matrix(0,N,K)
  result_PROJ_200_space = matrix(0,N,K)
  result_RobustTensor_space = matrix(0,N,K)
  result_HOOI_space = matrix(0,N,K)
  result_iTIPUP_space = matrix(0,N,K)
  # result_MatrixKendall_space = matrix(0,N,K)   # hide it for settings with K = 3 or 4
  # result_alphaPCA_space = matrix(0,N,K)        # hide it for settings with K = 3 or 4

  # result_PRE_400_space = matrix(0,N,K)         # unhide these if want to compare different M0 for PRE and PROJ
  # result_PRE_800_space = matrix(0,N,K)
  # result_PROJ_400_space = matrix(0,N,K)
  # result_PROJ_800_space = matrix(0,N,K)

  
  result_PRE_200_time = numeric(N)
  result_PROJ_200_time = numeric(N)
  result_RobustTensor_time = numeric(N)
  result_HOOI_time = numeric(N)
  result_iTIPUP_time = numeric(N)
  # result_MatrixKendall_time = numeric(N)      # hide it for settings with K = 3 or 4
  # result_alphaPCA_time = numeric(N)           # hide it for settings with K = 3 or 4
  
  # result_PRE_400_time = numeric(N)            # unhide these if want to compare different M0 for PRE and PROJ
  # result_PRE_800_time = numeric(N)
  # result_PROJ_400_time = numeric(N)
  # result_PROJ_800_time = numeric(N)


  set.seed(2023)
  print('factor loading estimation')
  for (n in 1:N)
  {
    print(n)
    each_start_time = Sys.time()
    Data_test = Data_read[[n]]
    X = Data_test[['X']]
    A = Data_test[['A']]

    # svd for the factor loading matrix
    U = list()
    for (k in 1:K)
    {
      U[[k]] = svd(A[[k]])$u
    }


    ## pre-averaging and iterative projection
    # M0 = 200
    pre_200_start_time <- Sys.time()
    Q_pre_200 = TensorPreAve::pre_est(X,z = r, M0 = 200)
    pre_200_end_time <- Sys.time()
    result_PRE_200_time[n] = pre_200_end_time - pre_200_start_time
    for (k in 1:K)
    {
      Q_PRE_k = Q_pre_200[[k]]
      result_PRE_200_space[n,k] = norm(Q_PRE_k %*% t(Q_PRE_k) - U[[k]] %*% t(U[[k]]),type = '2')
    }

    proj_200_start_time <- Sys.time()
    initial_direction = list()
    for (k in 1:K)
    {
      initial_direction[[k]] = (Q_pre_200[[k]][,1])
    }
    Q_proj_200 = TensorPreAve::iter_proj(X,Q_pre_200, z = r)
    proj_200_end_time <- Sys.time()
    result_PROJ_200_time[n] = proj_200_end_time - proj_200_start_time
    for (k in 1:K)
    {
      Q_proj_k = Q_proj_200[[k]]
      result_PROJ_200_space[n,k] = norm(Q_proj_k %*% t(Q_proj_k) - U[[k]] %*% t(U[[k]]),type = '2')
    }


    ## RTFA
    RT_start_time = Sys.time()
    HOSVD_estimator = HOSVD(X,z = r)
    RT_factor = robust_tensor_factor(X,z = r, INIT_Q = HOSVD_estimator)
    RT_end_time = Sys.time()
    result_RobustTensor_time[n] = RT_end_time - RT_start_time
    for (k in 1:K)
    {
      RT_estimator = RT_factor[[k]]
      result_RobustTensor_space[n,k] = norm(RT_estimator %*% t(RT_estimator) - U[[k]] %*% t(U[[k]]),type = '2')
    }



    ## PE (HOOI)
    HOOI_start_time = Sys.time()
    HOSVD_estimator = HOSVD(X,z = r)
    HOOI_factor = HOOI(X, z= r, INIT_Q = HOSVD_estimator)
    HOOI_end_time = Sys.time()
    result_HOOI_time[n] = HOOI_end_time - HOOI_start_time
    for (k in 1:K)
    {
      HOOI_estimator = HOOI_factor[[k]]
      result_HOOI_space[n,k] = norm(HOOI_estimator %*% t(HOOI_estimator) - U[[k]] %*% t(U[[k]]),type = '2')
    }


    ## iTIPUP
    iTIPUP_start_time = Sys.time()
    TIPUP_estimator = TIPUP(X, z = r, h0 = 1)
    iTIPUP_estimator = iTOPUP_TIPUP(X, z = r, h0 = 1, INIT_Q = TIPUP_estimator, UITER = 'TIPUP')
    iTIPUP_end_time = Sys.time()
    result_iTIPUP_time[n] = iTIPUP_end_time - iTIPUP_start_time
    for (k in 1:K)
    {
      iTIPUP_k = iTIPUP_estimator[[k]]
      result_iTIPUP_space[n,k] = norm(iTIPUP_k %*% t(iTIPUP_k) - U[[k]] %*% t(U[[k]]),type = '2')
    }
    
    # ## Hide these for K = 3 or 4
    # ## MRTS
    # MK_start_time = Sys.time()
    # MK_factor_rank = robust_kendall(X, z = r)
    # MK_end_time = Sys.time()
    # result_MatrixKendall_time[n] = MK_end_time - MK_start_time
    # for (k in 1:K)
    # {
    #   MK_estimator = MK_factor_rank[['A_hat']][[k]]
    #   result_MatrixKendall_space[n,k] = norm(MK_estimator %*% t(MK_estimator) - U[[k]] %*% t(U[[k]]),type = '2')
    # }
    #
    # ## alpha-PCA
    # aPCA_start_time = Sys.time()
    # aPCA_factor_rank = alpha_PCA(X, z = r)
    # aPCA_end_time = Sys.time()
    # result_alphaPCA_time[n] = aPCA_end_time - aPCA_start_time
    # for (k in 1:K)
    # {
    #   aPCA_estimator = aPCA_factor_rank[['A_hat']][[k]]
    #   result_alphaPCA_space[n,k] = norm(aPCA_estimator %*% t(aPCA_estimator) - U[[k]] %*% t(U[[k]]),type = '2')
    # }
    
    
    
    
    
    ## Unhide these if want to compare different M0 for pre-averaging and iterative projection
    # # M0 = 400
    # pre_400_start_time <- Sys.time()
    # Q_pre_400 = TensorPreAve::pre_est(X,z = r, M0 = 400)
    # pre_400_end_time <- Sys.time()
    # result_PRE_400_time[n] = pre_400_end_time - pre_400_start_time
    # for (k in 1:K)
    # {
    #   Q_PRE_k = Q_pre_400[[k]]
    #   result_PRE_400_space[n,k] = norm(Q_PRE_k %*% t(Q_PRE_k) - U[[k]] %*% t(U[[k]]),type = '2')
    # }
    #
    # proj_400_start_time <- Sys.time()
    # initial_direction = list()
    # for (k in 1:K)
    # {
    #   initial_direction[[k]] = (Q_pre_400[[k]][,1])
    # }
    # Q_proj_400 = TensorPreAve::iter_proj(X,Q_pre_400, z = r)
    # proj_400_end_time <- Sys.time()
    # result_PROJ_400_time[n] = proj_400_end_time - proj_400_start_time
    # for (k in 1:K)
    # {
    #   Q_proj_k = Q_proj_400[[k]]
    #   result_PROJ_400_space[n,k] = norm(Q_proj_k %*% t(Q_proj_k) - U[[k]] %*% t(U[[k]]),type = '2')
    # }
    #
    #
    # # M0 = 800
    # pre_800_start_time <- Sys.time()
    # Q_pre_800 = TensorPreAve::pre_est(X,z = r, M0 = 800)
    # pre_800_end_time <- Sys.time()
    # result_PRE_800_time[n] = pre_800_end_time - pre_800_start_time
    # for (k in 1:K)
    # {
    #   Q_PRE_k = Q_pre_800[[k]]
    #   result_PRE_800_space[n,k] = norm(Q_PRE_k %*% t(Q_PRE_k) - U[[k]] %*% t(U[[k]]),type = '2')
    # }
    #
    # proj_800_start_time <- Sys.time()
    # initial_direction = list()
    # for (k in 1:K)
    # {
    #   initial_direction[[k]] = (Q_pre_800[[k]][,1])
    # }
    # Q_proj_800 = TensorPreAve::iter_proj(X,Q_pre_800, z = r)
    # proj_800_end_time <- Sys.time()
    # result_PROJ_800_time[n] = proj_800_end_time - proj_800_start_time
    # for (k in 1:K)
    # {
    #   Q_proj_k = Q_proj_800[[k]]
    #   result_PROJ_800_space[n,k] = norm(Q_proj_k %*% t(Q_proj_k) - U[[k]] %*% t(U[[k]]),type = '2')
    # }

    each_end_time = Sys.time()
    print(each_end_time - each_start_time)
  }



  ### Save the estimation result into a csv file ###

  df_result = data.frame(cbind(result_PRE_200_space,
                               result_PROJ_200_space,
                               result_RobustTensor_space,
                               result_HOOI_space,
                               result_iTIPUP_space,
                               # result_MatrixKendall_space,
                               # result_alphaPCA_space,
                               
                               # result_PRE_400_space,
                               # result_PRE_800_space,
                               # result_PROJ_400_space,
                               # result_PROJ_800_space,
                               
                               result_PRE_200_time,
                               result_PROJ_200_time,
                               result_RobustTensor_time,
                               result_HOOI_time,
                               result_iTIPUP_time,
                               # result_MatrixKendall_time,
                               # result_alphaPCA_time,
                               
                               # result_PRE_400_time,
                               # result_PRE_800_time,
                               # result_PROJ_400_time,
                               # result_PROJ_800_time
                               ))
  
  
  names(df_result) = c(paste('PRE_200', 1:K , sep = "_"),
                       paste('PROJ_200', 1:K , sep = "_"),
                       paste('RobustTensor', 1:K , sep = "_"),
                       paste('HOOI', 1:K , sep = "_"),
                       paste('iTIPUP', 1:K , sep = "_"),
                       # paste('MatrixKendall', 1:K , sep = "_"),
                       # paste('alphaPCA', 1:K , sep = "_"),
                       
                       # paste('PRE_400', 1:K , sep = "_"),
                       # paste('PRE_800', 1:K , sep = "_"),
                       # paste('PROJ_400', 1:K , sep = "_"),
                       # paste('PROJ_800', 1:K , sep = "_"),
                       
                       'PRE_200_time',
                       'PROJ_200_time',
                       'RobustTensor_time',
                       'HOOI_time',
                       'iTIPUP_time',
                       # 'MatrixKendall_time',
                       # 'alphaPCA_time',
                       
                       # 'PRE_400_time',
                       # 'PRE_800_time',
                       # 'PROJ_400_time',
                       # 'PROJ_800_time'
                       )



  estimation_file_name = paste(file_name, 'Est',sep = '_')
  write.csv(df_result, file = paste(estimation_file_name,'.csv',sep = ''))






  ##### Estimations of Rank of the Core Tensor #####
  # N = 500
  # Create matrices which stores the result
  result_BsCorTh_rank = matrix(0,N,K)
  result_RobustTensor_rank = matrix(0,N,K)
  result_HOOI_rank = matrix(0,N,K)
  result_iTIP_ER_rank = matrix(0,N,K)
  # result_MatrixKendall_rank = matrix(0,N,K)    # hide it for settings with K = 3 or 4
  # result_alphaPCA_rank = matrix(0,N,K)         # hide it for settings with K = 3 or 4

  result_BsCorTh_time = numeric(N)
  result_RobustTensor_time = numeric(N)
  result_HOOI_time = numeric(N)
  result_iTIP_ER_time = numeric(N)
  # result_MatrixKendall_time = numeric(N)       # hide it for settings with K = 3 or 4
  # result_alphaPCA_time = numeric(N)            # hide it for settings with K = 3 or 4


  set.seed(2023)
  print('rank estimation')
  ### Start Estimation ###
  for (n in 1:N)
  {
    print(n)
    each_start_time = Sys.time()
    ## Read data
    Data_test = Data_read[[n]]
    X = Data_test[['X']]

    ## BCorTh
    # Pre-averaging Estimator
    bs_start_time = Sys.time()
    Q_pre = TensorPreAve::pre_est(X,z = rep(1,K))
    for (k in 1:K)
    {
      Q_hat_k = Q_pre[[k]]
    }
    # Iterative Projection
    initial_direction = list()
    for (k in 1:K)
    {
      initial_direction[[k]] = (Q_pre[[k]][,1])
    }
    Q_proj = TensorPreAve::iter_proj(X,initial_direction, proj_N = 30, z = rep(1,K))
    # Bootstrap for Estimation of Rank
    bs_rank = TensorPreAve::bs_cor_rank(X, Q_proj, B = 10)  # Alternatively, set B=10 for settings with K=3
    bs_end_time <- Sys.time()
    result_BsCorTh_time[n] = bs_end_time - bs_start_time
    for (k in 1:K)
    {
      result_BsCorTh_rank[n,k] = bs_rank[k]
    }



    ## RTFA-ER
    RT_start_time = Sys.time()
    HOSVD_estimator = HOSVD(X,z = floor(d/2))
    RT_factor_rank = robust_tensor_factor_ER(X, proj_N = 30, INIT_Q = HOSVD_estimator)
    RT_end_time = Sys.time()
    result_RobustTensor_time[n] = RT_end_time - RT_start_time
    for (k in 1:K)
    {
      result_RobustTensor_rank[n,k] = RT_factor_rank[['r_hat']][k]
    }


    ## PE-ER
    HOOI_start_time = Sys.time()
    HOSVD_estimator = HOSVD(X,z = floor(d/2))
    HOOI_factor_rank = HOOI_ER(X, proj_N = 30, HOSVD_estimator)
    HOOI_end_time = Sys.time()
    result_HOOI_time[n] = HOOI_end_time - HOOI_start_time
    for (k in 1:K)
    {
      result_HOOI_rank[n,k] = HOOI_factor_rank[['r_hat']][k]
    }

    ## iTIPUP-ER
    iTIP_start_time = Sys.time()
    # calculate initial TIPUP-ER
    TIPUP_result = TIPUP_ER(X, h0 = 1, ER_c = 0.1)
    TIPUP_estimator = TIPUP_result[['TIPUP_estimator']]
    TIPUP_rank = TIPUP_result[['ER']]
    # calculate iTIPUP-ER
    iTIP_ER_rank = iTIPUP_ER(X, h0 = 1, proj_N = 30, INIT_Q = TIPUP_estimator,initial_rank_estimator = TIPUP_rank, ER_c = 0.1)
    iTIP_end_time = Sys.time()
    result_iTIP_ER_time[n] = iTIP_end_time - iTIP_start_time
    for (k in 1:K)
    {
      result_iTIP_ER_rank[n,k] = iTIP_ER_rank[k]
    }
    
    # ## Hide these for K = 3 or 4
    # ## MRTS-ER
    # MK_start_time = Sys.time()
    # MK_factor_rank = robust_kendall(X, z = r)
    # MK_end_time = Sys.time()
    # result_MatrixKendall_time[n] = MK_end_time - MK_start_time
    # for (k in 1:K)
    # {
    #   result_MatrixKendall_rank[n,k] = MK_factor_rank[['r_hat']][k]
    # }
    #
    #
    # ## alpha-PCA-ER
    # aPCA_start_time = Sys.time()
    # aPCA_factor_rank = alpha_PCA(X, z = r)
    # aPCA_end_time = Sys.time()
    # result_alphaPCA_time[n] = aPCA_end_time - aPCA_start_time
    # for (k in 1:K)
    # {
    #   result_alphaPCA_rank[n,k] = aPCA_factor_rank[['r_hat']][k]
    # }

    each_end_time = Sys.time()
    print(each_end_time - each_start_time)


  }



  ### Save the estimation result into a csv file ###

  df_result = data.frame(cbind(result_BsCorTh_rank,
                               result_RobustTensor_rank,
                               result_HOOI_rank,
                               result_iTIP_ER_rank,
                               # result_MatrixKendall_rank,
                               # result_alphaPCA_rank,
                               
                               result_BsCorTh_time,
                               result_RobustTensor_time,
                               result_HOOI_time,
                               result_iTIP_ER_time,
                               # result_MatrixKendall_time,
                               # result_alphaPCA_time
                               ))
  
  
  names(df_result) = c(paste('BsCorTh_rank', 1:K , sep = "_"),
                       paste('RobustTensor_rank', 1:K , sep = "_"),
                       paste('HOOI_rank', 1:K , sep = "_"),
                       paste('iTIP_ER_rank', 1:K , sep = "_"),
                       # paste('MatrixKendall_rank', 1:K , sep = "_"),
                       # paste('alphaPCA_rank', 1:K , sep = "_"),
                       
                       'BsCorTh_time',
                       'RobustTensor_time',
                       'HOOI_time',
                       'iTIP_ER_time',
                       # 'MatrixKendall_time',
                       # 'alphaPCA_time'
                       )


  rank_file_name = paste(file_name, 'Rank',sep="_")
  write.csv(df_result, file = paste(rank_file_name,'.csv',sep = ''))


}
t112 <- Sys.time()
close(pb)
# stop cluster
stopCluster(cl)
print(t112-t111)





