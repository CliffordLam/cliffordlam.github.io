########################## This script is for real data analysis using Fama-French portfolios data ############################
library(MASS)
library(pracma)
library(rTensor)
library(TensorPreAve)
source("supporting_functions.R")



##### Pre-processed the data #####
value_weight_data = read.csv('ValueWeightedM-OP.csv', header = F)
equal_weight_data = read.csv('100_Portfolios_ME_OP_10x10.csv', header = F)

NYSE_return = read.csv('NYSEreturn.csv', header = F)



### Use CAPM to remove market effects
value_weight_demean = value_weight_data - apply(value_weight_data,1,mean)
equal_weight_demean = equal_weight_data - apply(equal_weight_data,1,mean)
NYSE_demean = NYSE_return[,1] - mean(NYSE_return[,1])

value_weight_CAPM = matrix(0,576,100)
for (i in 1:100)
{
  value_weight_CAPM[,i] = lm(value_weight_demean[,i]~NYSE_demean - 1)$residuals
}

equal_weight_CAPM = matrix(0,576,100)
for (i in 1:100)
{
  equal_weight_CAPM[,i] = lm(equal_weight_demean[,i]~NYSE_demean - 1)$residuals
}

value_weight_tensor = as.tensor(array(data.matrix(value_weight_CAPM),c(576,10,10)))
equal_weight_tensor = as.tensor(array(data.matrix(equal_weight_CAPM),c(576,10,10)))



##### Rank and factor loadings estimation  #####

## choose the portfolio to analyze
X = equal_weight_tensor      # Value weighted portfolio
# X = equal_weight_tensor     # Equal weight portfolio

K = length(X@modes) - 1


#### Estimate the rank of the core tensor ####

### Our method ###
set.seed(10)  
# Pre-averaging
Q_pre = pre_averaged_estimator(X, M0 = 25, M = 10)
# Iterative projection
initial_direction = list()
for (k in 1:K)
{
  initial_direction[[k]] = (Q_pre[[k]][,1])
}
Q_proj = Iterative_Projection(X,initial_direction, proj_N = 30, z = c(1,1))
# Bootstrap rank estimation 
bs_rank = Bootstrap_Sampling_Rank(X,Q_proj)

print('BsCorTh')
print(bs_rank)


### iTIPUP-ER ###

## h0 = 1
TIPUP_result = TIPUP_ER(X, h0 = 1, ER_c = 0.1)
TIPUP_estimator = TIPUP_result[['TIPUP_estimator']]
TIPUP_rank = TIPUP_result[['ER']]
iTIPUP_ER_rank = iTIPUP_ER(X, h0 = 1, proj_N = 30, INIT_Q = TIPUP_estimator,initial_rank_estimator = TIPUP_rank, ER_c = 0.1)
print(iTIPUP_ER_rank)



## PE-ER
d = X@modes[-1]
HOSVD_estimator = HOSVD(X, z = floor(d/2))
HOOI_factor_rank = HOOI_ER(X, proj_N = 30, HOSVD_estimator)
print(HOOI_factor_rank[['r_hat']])

## RTFA-ER
HOSVD_estimator = HOSVD(X,z = floor(d/2))
RT_factor_rank = robust_tensor_factor_ER(X, proj_N = 30, INIT_Q = HOSVD_estimator)
print(RT_factor_rank[['r_hat']])


## MRTS-ER
MK_factor_rank = robust_kendall(X, z = r)
print(MK_factor_rank[['r_hat']])


## alphaPCA-ER
aPCA_factor_rank = alpha_PCA(X, z = r)
print(aPCA_factor_rank[['r_hat']])


  
  
#### Estimation of factor loading spaces ####

### Iterative Projection ###
Q_proj = Iterative_Projection(X,initial_direction, proj_N = 30, z = c(2,2))
Q_hat_1 = Q_proj[[1]]
Q_hat_2 = Q_proj[[2]]

# varimax rotation and scaled by 30
print('PROJ: factor loading spaces')
round(varimax(Q_hat_1)$loadings[,1:2] * 30)
round(varimax(Q_hat_2)$loadings[,1:2] * 30)



### iTIPUP ###
TIPUP_estimator = TIPUP(X, z = c(2,2), h0 = 1)
iTIPUP_estimator = iTOPUP_TIPUP(X, z = c(2,2), h0 = 1,  proj_N = 30, INIT_Q = TIPUP_estimator, UITER = 'TIPUP')
iTIPUP_1 = iTIPUP_estimator[[1]]
iTIPUP_2 = iTIPUP_estimator[[2]]

# varimax rotation and scaled by 30
print('iTIPUP: factor loading spaces')
round(varimax(iTIPUP_1)$loadings[,1:2] * 30)
round(varimax(iTIPUP_2)$loadings[,1:2] * 30)



### PE ###

HOSVD_estimator = HOSVD(X,z = c(2,2))
HOOI_estimator = HOOI(X,z = c(2,2), proj_N = 30, INIT_Q = HOSVD_estimator)
HOOI_1 = HOOI_estimator[[1]]
HOOI_2 = HOOI_estimator[[2]]

# varimax rotation and scaled by 30
print('HOOI: factor loading spaces')
round(varimax(HOOI_1)$loadings[,1:2] * 30)
round(varimax(HOOI_2)$loadings[,1:2] * 30)













