##################################### This script is for analysis and plotting of the simulation results #############################
### It reads and summarizes the estimation results, draw the boxplots to compare different methods



###### Estimation results for factor loading spaces #####

#### K = 2 ####
heavy_tail = TRUE           # TRUE for t_3 distribution, FALSE for normal distribution

## Settings (i)(ii)
K = 2
T_list = rep(c(100,200),c(6,6))
d_list = c(rep(list(c(40,40)),6),rep(list(c(80,80)),6))

r = rep(2,K)                # Rank of core tensors
re = rep(2,K)               # Rank of the cross-sectional common error core tensors


## We draw the boxplots
eta_list = list(rep(list(c(0,0)),K),                      # Setting (I)
                rep(list(c(0,0.2)),K),                    # Setting (II)
                rep(list(c(0.1,0.2)),K))                  # Setting (III)

u_list <- list(rep(list(c(-2,2)),K),                      # Sub-setting (a)
               rep(list(c(0,2)),K))                       # Sub-setting (b)



eta_total <- rep(eta_list, 4)
u_total <- rep(u_list,6)

 

plot_data = list()


for (j in 1:12)
{
  eta <- eta_total[[j]]
  u <- u_total[[j]]
  T = T_list[j]
  d = d_list[[j]]
  
  para_list = list(
    'K' = K,
    'T' = T,
    'd' = d,
    'r' = r,
    're' = re,
    'eta' = eta,
    'u' = u)
  file_name = paste(names(para_list),para_list,sep="=",collapse="_")
  if (heavy_tail)
  {
    file_name = paste(file_name,'t3',sep = '_')
  }
  file_name = paste(file_name, 'Est',sep ='_')
  plot_data[[j]] = read.csv(paste(file_name,'.csv',sep = ''), header = T)
  
  plot_data[[j]] = plot_data[[j]][c('PROJ_200_1'
                         ,'iTIPUP_1'
                         ,'HOOI_1'
                         ,'alphaPCA_1'
                         ,'RobustTensor_1'
                         , 'MatrixKendall_1'
  )]
  
  names(plot_data[[j]]) = c('PROJ'
                    ,'iTIPUP'
                    ,'PE'
                    ,'aPCA'
                    ,'RTFA'
                    ,'MRTS'
  )
}


par(mfrow = c(3,2))
boxplot(log(cbind(plot_data[[1]],plot_data[[4]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (I), T = 100, '~d[k] ~'= 40'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[7]],plot_data[[10]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (I), T = 200,'~d[k] ~'= 80'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[5]],plot_data[[2]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (II), T = 100,'~d[k] ~'= 40'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[11]],plot_data[[8]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (II), T = 200,'~d[k] ~'= 80'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[3]],plot_data[[6]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (III), T = 100,'~d[k] ~'= 40'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[9]],plot_data[[12]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (III), T = 200,'~d[k] ~'= 80'),cex.main = 2.5)






#### K = 3 ####
heavy_tail = TRUE           # TRUE for t_3 distribution, FALSE for normal distribution

## Setting (iii)(iv)
K = 3
T_list = rep(200,12)
d_list = c(rep(list(c(15,15,15)),6),rep(list(c(25,25,25)),6))


r = rep(2,K)                # Rank of core tensors
re = rep(2,K)               # Rank of the cross-sectional common error core tensors


## We draw the boxplots
eta_list = list(rep(list(c(0,0)),K),                      # Setting (I)
                rep(list(c(0,0.2)),K),                    # Setting (II)
                rep(list(c(0.1,0.2)),K))                  # Setting (III)

u_list <- list(rep(list(c(-2,2)),K),                      # Sub-setting (a)
               rep(list(c(0,2)),K))                       # Sub-setting (b)



eta_total <- rep(eta_list, 4)
u_total <- rep(u_list,6)



plot_data = list()


for (j in 1:12)
{
  eta <- eta_total[[j]]
  u <- u_total[[j]]
  T = T_list[j]
  d = d_list[[j]]
  
  para_list = list(
    'K' = K,
    'T' = T,
    'd' = d,
    'r' = r,
    're' = re,
    'eta' = eta,
    'u' = u)
  file_name = paste(names(para_list),para_list,sep="=",collapse="_")
  if (heavy_tail)
  {
    file_name = paste(file_name,'t3',sep = '_')
  }
  file_name = paste(file_name, 'Est',sep ='_')
  plot_data[[j]] = read.csv(paste(file_name,'.csv',sep = ''), header = T)
  
  plot_data[[j]] = plot_data[[j]][c('PROJ_200_1'
                                    ,'iTIPUP_1'
                                    ,'HOOI_1'
                                    # ,'alphaPCA_1'
                                    ,'RobustTensor_1'
                                    # , 'MatrixKendall_1'
  )]
  
  names(plot_data[[j]]) = c('PROJ'
                            ,'iTIPUP'
                            ,'PE'
                            # ,'aPCA'
                            ,'RTFA'
                            # ,'MRTS'
  )
}


par(mfrow = c(3,2))
boxplot(log(cbind(plot_data[[1]],plot_data[[4]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (I), '~d[k] ~'= 15'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[7]],plot_data[[10]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (I), '~d[k] ~'= 25'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[5]],plot_data[[2]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (II), '~d[k] ~'= 15'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[11]],plot_data[[8]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (II), '~d[k] ~'= 25'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[3]],plot_data[[6]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (III), '~d[k] ~'= 15'),cex.main = 2.5)
boxplot(log(cbind(plot_data[[9]],plot_data[[12]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (III),,'~d[k] ~'= 25'),cex.main = 2.5)





#### K = 4 ####

## Setting (v)
K = 4
T_list = rep(200,12)
heavy_tail_list = rep(c(FALSE,TRUE),c(6,6))


r = rep(2,K)                # Rank of core tensors
re = rep(2,K)               # Rank of the cross-sectional common error core tensors


## We draw the boxplots
eta_list = list(rep(list(c(0,0)),K),                      # Setting (I)
                rep(list(c(0,0.2)),K),                    # Setting (II)
                rep(list(c(0.1,0.2)),K))                  # Setting (III)

u_list <- list(rep(list(c(-2,2)),K),                      # Sub-setting (a)
               rep(list(c(0,2)),K))                       # Sub-setting (b)



eta_total <- rep(eta_list, 4)
u_total <- rep(u_list,6)



plot_data = list()


for (j in 1:12)
{
  eta <- eta_total[[j]]
  u <- u_total[[j]]
  T = T_list[j]
  heavy_tail = heavy_tail_list[j]
  
  para_list = list(
    'K' = K,
    'T' = T,
    'd' = d,
    'r' = r,
    're' = re,
    'eta' = eta,
    'u' = u)
  file_name = paste(names(para_list),para_list,sep="=",collapse="_")
  if (heavy_tail)
  {
    file_name = paste(file_name,'t3',sep = '_')
  }
  file_name = paste(file_name, 'Est',sep ='_')
  plot_data[[j]] = read.csv(paste(file_name,'.csv',sep = ''), header = T)
  
  plot_data[[j]] = plot_data[[j]][c('PROJ_200_1'
                                    ,'iTIPUP_1'
                                    ,'HOOI_1'
                                    # ,'alphaPCA_1'
                                    # ,'RobustTensor_1'
                                    # , 'MatrixKendall_1'
  )]
  
  names(plot_data[[j]]) = c('PROJ'
                            ,'iTIPUP'
                            ,'PE'
                            # ,'aPCA'
                            # ,'RTFA'
                            # ,'MRTS'
  )
}


par(mfrow = c(3,2))
boxplot(log(cbind(plot_data[[1]],plot_data[[4]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (I), Normal '),cex.main = 2.5)
boxplot(log(cbind(plot_data[[7]],plot_data[[10]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (I), '~t[3]),cex.main = 2.5)
boxplot(log(cbind(plot_data[[5]],plot_data[[2]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (II), Normal '),cex.main = 2.5)
boxplot(log(cbind(plot_data[[11]],plot_data[[8]])),col = rep(c('red','blue'),c(6,6)),main = expression('Setting (II), '~t[3]),cex.main = 2.5)
boxplot(log(cbind(plot_data[[3]],plot_data[[6]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (III), Normal '),cex.main = 2.5)
boxplot(log(cbind(plot_data[[9]],plot_data[[12]])),col = rep(c('red','blue'),c(6,6)),main = expression( 'Setting (III), '~t[3]),cex.main = 2.5)









##### Estimation results for rank of the core tensors #####

### Change these for different dimensions

# (i)
K = 2                     # The number of modes for the tensor time series
T = 100                   # Length of time series
d = c(40,40)              # Dimensions of each mode of the tensor

# # (ii)
# K = 2
# T = 200
# d = c(80,80)
#
# # (iii)
# K = 3
# T = 200
# d = c(25,25,25)



r = rep(2,K)                # Rank of core tensors
re = rep(2,K)               # Rank of the cross-sectional common error core tensors


### Change these for different profiles
eta = rep(list(c(0,0)),K)                      # Setting (I)
# eta = rep(list(c(0,0.2)),K)                    # Setting (II)
# eta = rep(list(c(0.1,0.2)),K)                 # Setting (III)

u = rep(list(c(-2,2)),K)                      # Sub-setting (a)
# u = rep(list(c(0,0,2)),K)                     # Sub-setting (b)

heavy_tail = FALSE         # Change this for normal or t-3 errors             



para_list = list(
  'K' = K,
  'T' = T,
  'd' = d,
  'r' = r,
  're' = re,
  'eta' = eta,
  'u' = u)
file_name = paste(names(para_list),para_list,sep="=",collapse="_")
file_name = paste(file_name, 'Rank',sep ='_')
rank_data = read.csv(paste(file_name,'.csv',sep = ''), header = T)


### Correct Proportion

## K = 2
mean(apply(rank_data[c("BsCorTh_rank_1","BsCorTh_rank_2")] == r,1,prod))
mean(apply(rank_data[c("RobustTensor_rank_1","RobustTensor_rank_2")] == r,1,prod))
mean(apply(rank_data[c("MatrixKendall_rank_1","MatrixKendall_rank_2")] == r,1,prod))
mean(apply(rank_data[c("alphaPCA_rank_1","alphaPCA_rank_2")] == r,1,prod))
mean(apply(rank_data[c("HOOI_rank_1","HOOI_rank_2")] == r,1,prod))
mean(apply(rank_data[c('iTIP_ER_rank_1','iTIP_ER_rank_2')] == r,1,prod))


## K = 3
# mean(apply(rank_data[c("BsCorTh_rank_1","BsCorTh_rank_2","BsCorTh_rank_3")] == r,1,prod))
# mean(apply(rank_data[c("RobustTensor_rank_1","RobustTensor_rank_2","RobustTensor_rank_3")] == r,1,prod))
# mean(apply(rank_data[c("HOOI_rank_1","HOOI_rank_2","HOOI_rank_3")] == r,1,prod))
# mean(apply(rank_data[c('iTIP_ER_rank_1','iTIP_ER_rank_2','iTIP_ER_rank_3')] == r,1,prod))






##### Supplement: compare PRE and PROJ with different M0 #####
### Only run this after running the commented code to compare different M0 for PRE and PROJ in parallel_estimation.R

#### K = 2 ####
heavy_tail = TRUE         

K = 2
T_list = rep(c(100,200),c(2,2))
d_list = c(rep(list(c(40,40)),2),rep(list(c(80,80)),2))

r = rep(2,K)                # Rank of core tensors
re = rep(2,K)               # Rank of the cross-sectional common error core tensors


### Change these for different profiles
eta = rep(list(c(0,0)),K)                      # Setting (I)
# eta = rep(list(c(0,0.2)),K)                  # Setting (II)
# eta = rep(list(c(0.1,0.2)),K)                # Setting (III)

u_list <- list(rep(list(c(-2,2)),K),                      # Sub-setting (a)
               rep(list(c(0,2)),K))                       # Sub-setting (b)


u_total <- rep(u_list,2)

plot_data = list()


for (j in 1:4)
{
  u <- u_total[[j]]
  T = T_list[j]
  d = d_list[[j]]
  
  para_list = list(
    'K' = K,
    'T' = T,
    'd' = d,
    'r' = r,
    're' = re,
    'eta' = eta,
    'u' = u)
  file_name = paste(names(para_list),para_list,sep="=",collapse="_")
  if (heavy_tail)
  {
    file_name = paste(file_name,'t3',sep = '_')
  }
  file_name = paste(file_name, 'Est',sep ='_')
  plot_data[[j]] = read.csv(paste(file_name,'.csv',sep = ''), header = T)
  
  plot_data[[j]] = plot_data[[j]][c('PRE_200_1',
                         'PRE_400_1',
                         'PRE_800_1',
                         'PROJ_200_1',
                         'PROJ_400_1',
                         'PROJ_800_1'
  )]
  names(plot_data[[j]]) = c('PRE_200',
                    'PRE_400',
                    'PRE_800',
                    'PROJ_200',
                    'PROJ_400',
                    'PROJ_800'
  )
}

par(mfrow = c(2,2))
boxplot(log(plot_data[[1]]),main = expression( 'Sub-setting (a), T = 100,'~d[k] ~'= 40' ),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))
boxplot(log(plot_data[[2]]),main = expression('Sub-setting (b), T = 100,'~d[k] ~'= 40'),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))
boxplot(log(plot_data[[3]]),main = expression( 'Sub-setting (a), T = 200,'~d[k] ~'= 80' ),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))
boxplot(log(plot_data[[4]]),main = expression('Sub-setting (b), T = 200,'~d[k] ~'= 80'),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))




#### K = 3 #### 
heavy_tail = TRUE         

K = 3

r = rep(2,K)                # Rank of core tensors
re = rep(2,K)               # Rank of the cross-sectional common error core tensors


### Change these for different profiles
eta_list = list(rep(list(c(0,0)),K),                      # Setting (I)
                rep(list(c(0,0.2)),K),                    # Setting (II)
                rep(list(c(0.1,0.2)),K))                  # Setting (III)

u_list <- list(rep(list(c(-2,2)),K),                      # Sub-setting (a)
               rep(list(c(0,2)),K))                       # Sub-setting (b)


eta_total = rep(eta_list,2)
u_total <- rep(u_list,3)



plot_data = list()


for (j in 1:6)
{
  eta = eta_total[[j]]
  u <- u_total[[j]]
  T = 200
  d = c(15,15,15)
  
  para_list = list(
    'K' = K,
    'T' = T,
    'd' = d,
    'r' = r,
    're' = re,
    'eta' = eta,
    'u' = u)
  file_name = paste(names(para_list),para_list,sep="=",collapse="_")
  if (heavy_tail)
  {
    file_name = paste(file_name,'t3',sep = '_')
  }
  file_name = paste(file_name, 'Est',sep ='_')
  plot_data[[j]] = read.csv(paste(file_name,'.csv',sep = ''), header = T)
  
  plot_data[[j]] = plot_data[[j]][c('PRE_200_1',
                                    'PRE_400_1',
                                    'PRE_800_1',
                                    'PROJ_200_1',
                                    'PROJ_400_1',
                                    'PROJ_800_1'
  )]
  names(plot_data[[j]]) = c('PRE_200',
                            'PRE_400',
                            'PRE_800',
                            'PROJ_200',
                            'PROJ_400',
                            'PROJ_800'
  )
}

par(mfrow = c(3,2))
boxplot(log(plot_data[[1]]),main = expression( 'Setting (Ia)' ),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))
boxplot(log(plot_data[[4]]),main = expression('Setting (Ib)'),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))
boxplot(log(plot_data[[5]]),main = expression( 'Setting (IIa)' ),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))
boxplot(log(plot_data[[2]]),main = expression('Setting (IIb)'),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))
boxplot(log(plot_data[[3]]),main = expression( 'Setting (IIIa)' ),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))
boxplot(log(plot_data[[6]]),main = expression('Setting (IIIb)'),cex.main = 2.5, col = rep(c('red','blue'),c(3,3)))






