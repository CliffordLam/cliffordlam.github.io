####################### This script provides functions for estimations methods from other papers ###############

###################################### Function for TOPUP/TIPUP Estimator ##############################
# TOPUP = function(  X
#                  , z               # (estimated) number of factors
#                  , h0              # total lag of autocovariance, see Chen (2020)
# )
#   # output : a list of K matrices, where output[[k]] is the mode-k estimated factor loading matrix
# {
#   K = length(X@modes) - 1
#   d = X@modes[2:(K+1)]
#   T = X@modes[1]
#
#   # Demean X
#   X_mean = apply(X@data, 2:(K+1), mean)
#   X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
#   X_demean = as.tensor(X@data - X_mean_T)
#
#
#   TOPUP_estimator = list()
#
#
#   for (k in 1:K)
#   {
#     d_k = d[k]
#     z_k = z[k]
#     d_minus_k = prod(d) / d_k
#     unfold_X_k = unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])
#
#
#     TOPUP = as.tensor(array(0,c(d_k,d_minus_k,d_k,d_minus_k,h0)))
#
#     # Calculate the TOPUP tensor
#     for (h in 1:h0)
#     {
#       TOPUP_init = 0
#
#       for (t in (h+1):T)
#       {
#         TOPUP_init = TOPUP_init + outer(unfold_X_k[((t-h-1)*d_k + 1):((t-h)*d_k)]@data, unfold_X_k[((t-1)*d_k + 1):((t)*d_k)]@data)
#
#       }
#
#       TOPUP_init = as.tensor(TOPUP_init / (T - h))
#
#       TOPUP[,,,,h] = TOPUP_init
#
#     }
#
#     # SVD for finding the estimator of factor loadings
#     TOPUP_k_estimator = svd(unfold(TOPUP,row_idx = 1,col_idx = 2:5)@data)$u[,1:z_k]
#
#
#     TOPUP_estimator[[k]] = TOPUP_k_estimator
#
#
#   }
#
#   return(TOPUP_estimator)
# }




TIPUP = function(  X               # the target 'Tensor' object, where mode-1 is the time mode
                 , z               # (estimated) number of factors
                 , h0 = 1          # total lag of autocovariance, see Chen (2020)
)
  # output : a list of K matrices, where output[[k]] is the mode-k estimated factor loading matrix
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)


  TIPUP_estimator = list()

  for (k in 1:K)
  {
    d_k = d[k]
    z_k = z[k]
    d_minus_k = prod(d) / d_k
    unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])



    TIPUP = rTensor::as.tensor(array(0,c(d_k,d_k,h0)))

    # Calculate the TIPUP tensor
    for (h in 1:h0)
    {

      TIPUP_init = 0
      for (t in (h+1):T)
      {

        TIPUP_init = TIPUP_init + unfold_X_k[((t-h-1)*d_k + 1):((t-h)*d_k)]@data %*% t(unfold_X_k[((t-1)*d_k + 1):((t)*d_k)]@data)
      }


      TIPUP_init = rTensor::as.tensor(TIPUP_init / (T - h))

      TIPUP[,,h] = TIPUP_init
    }

    # SVD for finding the estimator of factor loadings

    TIPUP_k_estimator = svd(rTensor::unfold(TIPUP,row_idx = 1,col_idx = 2:3)@data)$u[,1:z_k]

    TIPUP_estimator[[k]] = TIPUP_k_estimator

  }

  return(TIPUP_estimator)
}


############################# Functions for iTOPUP/iTIPUP estimators #################################

################################# TOPUP/TIPUP estimation for the k-mode ##############################
# TOPUP_k = function(  X
#                    , z     # (estimated) number of factors
#                    , h0    # total lag of autocovariance, see Chen (2020)
#                    , k     # the mode for estimation
# )
#   # output : a matrix, which is the mode-k estimated factor loading matrix
# {
#   K = length(X@modes) - 1
#   d = X@modes[2:(K+1)]
#   T = X@modes[1]
#
#   # Demean X
#   X_mean = apply(X@data, 2:(K+1), mean)
#   X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
#   X_demean = as.tensor(X@data - X_mean_T)
#
#
#   # Calculate TOPUP for mode-k
#   d_k = d[k]
#   z_k = z[k]
#   d_minus_k = prod(d) / d_k
#   unfold_X_k = unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])
#
#
#   TOPUP = as.tensor(array(0,c(d_k,d_minus_k,d_k,d_minus_k,h0)))
#
#   # Calculate the TOPUP tensor
#   for (h in 1:h0)
#   {
#     TOPUP_init = 0
#     for (t in (h+1):T)
#     {
#       TOPUP_init = TOPUP_init + outer(unfold_X_k[((t-h-1)*d_k + 1):((t-h)*d_k)]@data, unfold_X_k[((t-1)*d_k + 1):((t)*d_k)]@data)
#     }
#
#     TOPUP_init = as.tensor(TOPUP_init / (T - h))
#     TOPUP[,,,,h] = TOPUP_init
#   }
#
#   # SVD for finding the estimator of factor loadings
#   TOPUP_k_estimator = svd(unfold(TOPUP,row_idx = 1,col_idx = 2:5)@data)$u[,1:z_k]
#   return(TOPUP_k_estimator)
# }


TIPUP_k = function(X          # the target 'Tensor' object, where mode-1 is the time mode
                    , z       # (estimated) number of factors
                    , h0      # total lag of autocovariance, see Chen (2020)
                    , k       # the mode for estimation
)
  # output : a matrix, which is the mode-k estimated factor loading matrix
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)

  # Calculate TIPUP for mode-k
  d_k = d[k]
  z_k = z[k]
  d_minus_k = prod(d) / d_k
  unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])


  TIPUP = rTensor::as.tensor(array(0,c(d_k,d_k,h0)))

  # Calculate the TIPUP tensor
  for (h in 1:h0)
  {
    TIPUP_init = 0
    for (t in (h+1):T)
    {
      TIPUP_init = TIPUP_init + unfold_X_k[((t-h-1)*d_k + 1):((t-h)*d_k)]@data %*% t(unfold_X_k[((t-1)*d_k + 1):((t)*d_k)]@data)
    }

    TIPUP_init = rTensor::as.tensor(TIPUP_init / (T - h))
    TIPUP[,,h] = TIPUP_init
  }

  # SVD for finding the estimator of factor loadings
  TIPUP_k_estimator = svd(rTensor::unfold(TIPUP,row_idx = 1,col_idx = 2:3)@data)$u[,1:z_k]

  return(TIPUP_k_estimator)
}


# ##### TIPUP_k with eigenvalues recorded #####
# TIPUP_k_plot = function(X    # the target 'Tensor' object, where mode-1 is the time mode
#                    , z       # (estimated) number of factors
#                    , h0      # total lag of autocovariance, see Chen (2020)
#                    , k       # the mode for estimation
# )
#   # output : a list of two elements
#   #                         output$TIPUP_k_estimator: a matrix, which is the mode-k estimated factor loading matrix
#   #                         output#eigen_record: a vector which record the eigenvalues of the TIPUP covariance matrix
# {
#   K = length(X@modes) - 1
#   d = X@modes[2:(K+1)]
#   T = X@modes[1]
#
#   # Demean X
#   X_mean = apply(X@data, 2:(K+1), mean)
#   X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
#   X_demean = rTensor::as.tensor(X@data - X_mean_T)
#
#   # Calculate TIPUP for mode-k
#   d_k = d[k]
#   z_k = z[k]
#   d_minus_k = prod(d) / d_k
#   unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])
#
#
#   TIPUP = rTensor::as.tensor(array(0,c(d_k,d_k,h0)))
#
#   # Calculate the TIPUP tensor
#   for (h in 1:h0)
#   {
#     TIPUP_init = 0
#     for (t in (h+1):T)
#     {
#       TIPUP_init = TIPUP_init + unfold_X_k[((t-h-1)*d_k + 1):((t-h)*d_k)]@data %*% t(unfold_X_k[((t-1)*d_k + 1):((t)*d_k)]@data)
#     }
#
#     TIPUP_init = rTensor::as.tensor(TIPUP_init / (T - h))
#     TIPUP[,,h] = TIPUP_init
#   }
#
#   # SVD for finding the estimator of factor loadings
#   TIPUP_k_estimator = svd(rTensor::unfold(TIPUP,row_idx = 1,col_idx = 2:3)@data)$u[,1:z_k]
#   eigen_record = svd(rTensor::unfold(TIPUP,row_idx = 1,col_idx = 2:3)@data)$d[1:d_k]^2
#
#   return(list('TIPUP_k_estimator' = TIPUP_k_estimator, 'eigen_record' = eigen_record))
# }




############################### Function for iterative TOPUP/TIPUP #################################
iTOPUP_TIPUP = function(  X                 # the target 'Tensor' object, where mode-1 is the time mode
                        , z                 # (estimated) number of factors
                        , h0 = 1            # total lag of autocovariance, see Chen (2020)
                        , proj_N = 30       # number of iterations
                        , INIT_Q            # the initial estimator, written in a list of K matrices
                        , UITER = 'TIPUP'   # type of iterative steps: 'TOPUP' or 'TIPUP'
)
  # output : a list of K matrices, where output[[k]] is the mode-k estimated factor loading matrix
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)

  # Initialize the factor loading estimators
  hat_Q_iter = INIT_Q

  # Iterations for iTOPUP/iTIPUP
  for (proj_n in 1:proj_N)
  {
    for (k in 1:K)
    {
      # Calculate the tensor to decompose
      temp_tensor = X_demean
      for (j in (1:K)[-k])
      {

        temp_tensor = rTensor::ttm(tnsr = temp_tensor, mat = t(hat_Q_iter[[j]]), m = j+1)

      }

      # Perform UITER on the new tensor series
      if (UITER == 'TIPUP') {
        hat_Q_iter_k = TIPUP_k(temp_tensor, z, h0 = h0, k = k)}
      else if (UITER == 'TOPUP') {hat_Q_iter_k = TOPUP_k(temp_tensor, z, h0 = h0, k = k)}
      else print('UITER input not valid')

      hat_Q_iter[[k]] = hat_Q_iter_k

    }
  }
  return(hat_Q_iter)
}


# ##### iTIPUP with eigenvalues recorded #####
# iTOPUP_TIPUP_plot = function(  X              # the target 'Tensor' object, where mode-1 is the time mode
#                           , z                 # (estimated) number of factors
#                           , h0 = 1            # total lag of autocovariance, see Chen (2020)
#                           , proj_N = 30       # number of iterations
#                           , INIT_Q            # the initial estimator, written in a list of K matrices
#                           , UITER = 'TIPUP'   # type of iterative steps: 'TOPUP' or 'TIPUP'
# )
#   # output : a list of two elements
#   #                      output#hat_Q_iter: a list of K matrices, which correspond to the mode-k estimated factor loading matrix
#   #                      output#eigen_record: a list of K vectors, which records the eigenvalues of the TIPUP covariance matrix from last iteration
# {
#   K = length(X@modes) - 1
#   d = X@modes[2:(K+1)]
#   T = X@modes[1]
#
#   # Demean X
#   X_mean = apply(X@data, 2:(K+1), mean)
#   X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
#   X_demean = rTensor::as.tensor(X@data - X_mean_T)
#
#   # Initialize the factor loading estimators
#   hat_Q_iter = INIT_Q
#
#   eigen_record = list()
#   # Iterations for iTOPUP/iTIPUP
#   for (proj_n in 1:proj_N)
#   {
#     for (k in 1:K)
#     {
#       # Calculate the tensor to decompose
#       temp_tensor = X_demean
#       for (j in (1:K)[-k])
#       {
#
#         temp_tensor = rTensor::ttm(tnsr = temp_tensor, mat = t(hat_Q_iter[[j]]), m = j+1)
#
#       }
#
#       # Perform UITER on the new tensor series
#       if (UITER == 'TIPUP') {
#         hat_Q_iter_k = TIPUP_k_plot(temp_tensor, z, h0 = h0, k = k)$TIPUP_k_estimator}
#       else if (UITER == 'TOPUP') {hat_Q_iter_k = TOPUP_k(temp_tensor, z, h0 = h0, k = k)}
#       else print('UITER input not valid')
#
#       hat_Q_iter[[k]] = hat_Q_iter_k
#
#       if (proj_n == proj_N)
#       {
#         eigen_record[[k]] = TIPUP_k_plot(temp_tensor, z, h0 = h0, k = k)$eigen_record
#       }
#     }
#   }
#   return(list('hat_Q_iter' = hat_Q_iter, 'eigen_record' = eigen_record))
# }



##################################### Functions for HOSVD/HOOI(PE) ######################################

######################################## Function for HOSVD ########################
HOSVD = function(  X     # the target 'Tensor' object, where mode-1 is the time mode
                 , z     # (estimated) number of factors
)
  # output : a list of K matrices, where output[[k]] is the mode-k estimated factor loading matrix
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)


  HOSVD_estimator = list()

  # Calculate HOSVD
  for (k in 1:K)
  {
    d_k = d[k]
    z_k = z[k]
    d_minus_k = prod(d) / d_k
    unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])
    HOSVD_init = 0
    for (t in 1:T)
    {
      HOSVD_init = HOSVD_init + unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data %*% t(unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data)
    }
    HOSVD_init = rTensor::as.tensor(HOSVD_init / T)
    HOSVD_estimator[[k]] = eigen(HOSVD_init@data)$vectors[,1:z_k]
  }
  return(HOSVD_estimator)
}

####################################### HOSVD for the k-mode ##############################
HOSVD_k = function(X      # the target 'Tensor' object, where mode-1 is the time mode
                   , z    # (estimated) number of factors
                   , k    # the mode for estimation
)
  # output : a matrix, which is the mode-k estimated factor loading matrix
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)


  # Calculate HOSVD for mode-k
  d_k = d[k]
  z_k = z[k]
  d_minus_k = prod(d) / d_k
  unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])



  # Calculate the HOSVD tensor

  HOSVD_init = 0
  for (t in 1:T)
  {
    HOSVD_init = HOSVD_init + unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data %*% t(unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data)
  }

  HOSVD_init = rTensor::as.tensor(HOSVD_init / T)


  # SVD for finding the estimator of factor loadings
  HOSVD_k_estimator = eigen(HOSVD_init@data)$vectors[,1:z_k]
  return(HOSVD_k_estimator)
}


# ##### HOSVD_k with eigenvalues recorded ####3
# HOSVD_k_plot = function(X # the target 'Tensor' object, where mode-1 is the time mode
#                    , z    # (estimated) number of factors
#                    , k    # the mode for estimation
# )
#   # output : a list of two elements
#   #                         output$HOSVD_k_estimator: a matrix, which is the mode-k estimated factor loading matrix
#   #                         output#eigen_record: a vector which record the eigenvalues of the HOSVD covariance matrix
# {
#   K = length(X@modes) - 1
#   d = X@modes[2:(K+1)]
#   T = X@modes[1]
#
#   # Demean X
#   X_mean = apply(X@data, 2:(K+1), mean)
#   X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
#   X_demean = rTensor::as.tensor(X@data - X_mean_T)
#
#
#   # Calculate HOSVD for mode-k
#   d_k = d[k]
#   z_k = z[k]
#   d_minus_k = prod(d) / d_k
#   unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])
#
#
#
#   # Calculate the HOSVD tensor
#
#   HOSVD_init = 0
#   for (t in 1:T)
#   {
#     HOSVD_init = HOSVD_init + unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data %*% t(unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data)
#   }
#
#   HOSVD_init = rTensor::as.tensor(HOSVD_init / T)
#
#   # SVD for finding the estimator of factor loadings
#   HOSVD_k_estimator = eigen(HOSVD_init@data)$vectors[,1:z_k]
#
#   eigen_record = eigen(HOSVD_init@data)$values[1:d_k]
#   return(list('HOSVD_k_estimator' = HOSVD_k_estimator, 'eigen_record' = eigen_record))
# }


###################################### Function for HOOI(PE) #######################################
HOOI = function(  X              # the target 'Tensor' object, where mode-1 is the time mode
                , z              # (estimated) number of factors
                , proj_N  = 30   # number of iterations
                , INIT_Q         # the initial estimator, written in a list of K matrices
)
  # output : a list of K matrices, where output[[k]] is the mode-k estimated factor loading matrix
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)

  # Initialize the factor loading estimator
  hat_Q_iter = INIT_Q

  # Iterations for HOOI
  for (proj_n in 1:proj_N)
  {
    for (k in 1:K)
    {
      # Calculate the tensor to decompose
      temp_tensor = X_demean
      for (j in (1:K)[-k])
      {

        temp_tensor = rTensor::ttm(tnsr = temp_tensor, mat = t(hat_Q_iter[[j]]), m = j+1)

      }

      # Perform SVD on the new tensor series
      hat_Q_iter_k = HOSVD_k(temp_tensor, z, k = k)
      hat_Q_iter[[k]] = hat_Q_iter_k

      }



  }
  return(hat_Q_iter)
}

# ##### HOOI with eigenvalues recorded #####
# HOOI_plot = function(  X           # the target 'Tensor' object, where mode-1 is the time mode
#                   , z              # (estimated) number of factors
#                   , proj_N = 30    # number of iterations
#                   , INIT_Q         # the initial estimator, written in a list of K matrices
# )
#   # output : a list of two elements
#   #                      output#hat_Q_iter: a list of K matrices, which correspond to the mode-k estimated factor loading matrix
#   #                      output#eigen_record: a list of K vectors, which records the eigenvalues of the HOOI covariance matrix from last iteration
# {
#   K = length(X@modes) - 1
#   d = X@modes[2:(K+1)]
#   T = X@modes[1]
#
#   # Demean X
#   X_mean = apply(X@data, 2:(K+1), mean)
#   X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
#   X_demean = rTensor::as.tensor(X@data - X_mean_T)
#
#   # Initialize the factor loading estimator
#   hat_Q_iter = INIT_Q
#
#   eigen_record = list()
#
#   # Iterations for HOOI
#   for (proj_n in 1:proj_N)
#   {
#     for (k in 1:K)
#     {
#       # Calculate the tensor to decompose
#       temp_tensor = X_demean
#       for (j in (1:K)[-k])
#       {
#
#         temp_tensor = rTensor::ttm(tnsr = temp_tensor, mat = t(hat_Q_iter[[j]]), m = j+1)
#
#       }
#
#       # Perform SVD on the new tensor series
#       hat_Q_iter_k = HOSVD_k_plot(temp_tensor, z, k = k)$HOSVD_k_estimator
#       hat_Q_iter[[k]] = hat_Q_iter_k
#
#       if (proj_n == proj_N)
#       {
#         eigen_record[[k]] = HOSVD_k_plot(temp_tensor, z, k = k)$eigen_record
#       }
#     }
#   }
#   return(list('hat_Q_iter' = hat_Q_iter, 'eigen_record' = eigen_record))
# }











###################################### Functions for iTIP-ER for rank estimation ##########################
###################################### Function for (initial) TIPUP-ER ##########################################
TIPUP_ER = function(X                   # the target 'Tensor' object, where mode-1 is the time mode
                    , h0 = 1            # total lag of autocovariance, see Chen (2020)
                    , ER_c = 0.1        # tuning parameters for ER
)
  # output : a list of two elements,
  # output[[1]] is a list of K matrices, indicating the mode-k estimated factor loading matrices,
  # output[[2]] is a vector of length K, which is the estimation for rank of core tensor
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)

  ER = numeric(K)
  TIPUP_estimator = list()

  # Calculate TIPUP
  for (k in 1:K)
  {
    # Estimate TIPUP-ER
    ER[k] = TIPUP_ER_k(X,h0,k,ER_c)

    d_k = d[k]
    d_minus_k = prod(d) / d_k
    unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])



    TIPUP = rTensor::as.tensor(array(0,c(d_k,d_k,h0)))

    # Calculate the TIPUP tensor
    for (h in 1:h0)
    {

      TIPUP_init = 0
      for (t in (h+1):T)
      {

        TIPUP_init = TIPUP_init + unfold_X_k[((t-h-1)*d_k + 1):((t-h)*d_k)]@data %*% t(unfold_X_k[((t-1)*d_k + 1):((t)*d_k)]@data)
      }


      TIPUP_init = rTensor::as.tensor(TIPUP_init / (T - h))

      TIPUP[,,h] = TIPUP_init
    }

    # SVD for finding the estimator of factor loadings

    TIPUP_k_estimator = svd(rTensor::unfold(TIPUP,row_idx = 1,col_idx = 2:3)@data)$u[,1:ER[k]]

    TIPUP_estimator[[k]] = TIPUP_k_estimator

  }

  return(list('TIPUP_estimator'=TIPUP_estimator, 'ER'=ER))
}





#################################### Function for TIPUP-ER of mode-k ##################################
TIPUP_ER_k = function(X         # the target 'Tensor' object, where mode-1 is the time mode
                      , h0      # total lag of autocovariance, see Chen (2020)
                      , k       # the mode for estimation
                      , ER_c    # tuning parameters for ER
)
  # output : a vector of length K, which is the estimation for rank of core tensor
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)


  # Calculate TIPUP for mode-k
  d_k = d[k]
  d_minus_k = prod(d) / d_k
  unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])

  TIPUP = rTensor::as.tensor(array(0,c(d_k,d_k,h0)))

  # Calculate the TIPUP tensor
  for (h in 1:h0)
  {
    TIPUP_init = 0
    for (t in (h+1):T)
    {
      TIPUP_init = TIPUP_init + unfold_X_k[((t-h-1)*d_k + 1):((t-h)*d_k)]@data %*% t(unfold_X_k[((t-1)*d_k + 1):((t)*d_k)]@data)
    }

    TIPUP_init = rTensor::as.tensor(TIPUP_init / (T - h))
    TIPUP[,,h] = TIPUP_init
  }


  # W_hat for TIPUP_k
  TIPUP_k_matrix = rTensor::unfold(TIPUP,row_idx = 1,col_idx = 2:3)@data
  W_hat = TIPUP_k_matrix %*% t(TIPUP_k_matrix)

  eigen_W_hat = eigen(W_hat)$values


  # calculate TIPUP_ER_k

  penalty_h = ER_c * h0   # penalty function

  ER_seq = (eigen_W_hat[2:100] + penalty_h)[1:(d_k/2)] / (eigen_W_hat + penalty_h)[1:(d_k/2)]
  ER_k = which.min(ER_seq)


  return(ER_k)
}


################################### Function for iTIPUP-ER ############################################

iTIPUP_ER = function(  X                       # the target 'Tensor' object, where mode-1 is the time mode
                     , h0 = 1                  # total lag of autocovariance, see Chen (2020)
                     , proj_N = 30             # number of iterations
                     , INIT_Q                  # initial estimator of factor loading space (obtained from TIPUP-ER)
                     , ER_c = 0.1              # tuning parameters for ER
                     , initial_rank_estimator  # initial estimator of rank of core tensor (obtained from TIPUP-ER)
)
  # output : a vector of length K, which is the estimation for rank of core tensor
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)


  # Initialize the rank and factor loading estimators
  ER = initial_rank_estimator
  hat_Q_iter = INIT_Q

  # Iterations to calculate iTIPUP-ER
  for (proj_n in 1:proj_N)
  {
    for (k in 1:K)
    {
      # Calculate the tensor to decompose
      temp_tensor = X_demean
      for (j in (1:K)[-k])
      {

        temp_tensor = rTensor::ttm(tnsr = temp_tensor, mat = t(hat_Q_iter[[j]]), m = j+1)

      }

      # Calculate iTIPUP_ER

      ER[k] = TIPUP_ER_k(temp_tensor, h0 = h0, k = k, ER_c = ER_c)

      # Perform UITER on the new tensor series

      hat_Q_iter_k = TIPUP_k(temp_tensor, z = ER, h0 = h0, k = k)
      hat_Q_iter[[k]] = hat_Q_iter_k



    }



  }

  return(ER)
}












############################ Function for alpha-PCA and alpha-PCA-ER ##################################

alpha_PCA = function(  X     # the target 'Tensor' object, where mode-1 is the time mode
                   , z     # (estimated) number of factors
                   ,alpha = 0 # tuning parameter
)
  # output: a list of two elements
  #                  output$r_hat : a vector of K elements of estimated number of factors in each mode, where K is the number of modes for the tensor time series
  #                  output$A_hat: a list of K estimated factor loading matrices
{
  K = length(X@modes) - 1
  if (K != 2)
  {
    print('alpha-PCA only works for K = 2.')
    break
  }
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Mean of X
  X_mean = apply(X@data, 2:(K+1), mean)
  # X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  # X_demean = rTensor::as.tensor(X@data - X_mean_T)

  alpha_PCA_estimator = list()

  # Calculate alpha-PCA for factor loading matrix
    M_1 = matrix(0,d[1],d[1])
    for (t in 1:T)
    {
      M_1 = M_1 + (X[t,,]@data - X_mean) %*% t(X[t,,]@data - X_mean)
    }
    M_1 = (M_1 / T + (1 + alpha) * X_mean %*% t(X_mean)) / prod(d)
    alpha_PCA_estimator[[1]] = eigen(M_1)$vectors[,1:z[1]]

    M_2 = matrix(0,d[2],d[2])
    for (t in 1:T)
    {
      M_2 = M_2 + t(X[t,,]@data - X_mean) %*% (X[t,,]@data - X_mean)
    }
    M_2 = (M_2 / T + (1 + alpha) * t(X_mean) %*% X_mean) / prod(d)
    alpha_PCA_estimator[[2]] = eigen(M_2)$vectors[,1:z[2]]


    ## Estimating the number of factors
    eigen_M_1 = eigen(M_1)$values[1:(d[1]/2)]
    ER_seq_1 = exp(-diff(log(eigen_M_1)))
    ER_1 = which.max(ER_seq_1)

    eigen_M_2 = eigen(M_2)$values[1:(d[2]/2)]
    ER_seq_2 = exp(-diff(log(eigen_M_2)))
    ER_2 = which.max(ER_seq_2)




  return(list('A_hat'=alpha_PCA_estimator,'r_hat'= c(ER_1,ER_2)))
}




################## He (2022): Matrix's kendall's tau (MRTS and MRTS-ER) #########################

robust_kendall = function(  X     # the target 'Tensor' object, where mode-1 is the time mode
                                   , z     # (estimated) number of factors
)
  # output: a list of two elements
  #                  output$r_hat : a vector of K elements of estimated number of factors in each mode, where K is the number of modes for the tensor time series
  #                  output$A_hat: a list of K estimated factor loading matrices
{
  K = length(X@modes) - 1
  if (K != 2)
  {
    print('MRTS only works for K = 2.')
    break
  }
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean of X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)

  kendall_estimator = list()

  # Calculate kendall's tau for factor loading matrix
  M_1 = matrix(0, d[1],d[1])
  for (t1 in 1:(T-1))
  {
    for (t2 in (t1+1):T)
    {
      M_1 = M_1 + (X[t1,,]@data - X[t2,,]@data) %*% t((X[t1,,]@data - X[t2,,]@data)) / norm(X[t1,,]@data - X[t2,,]@data, type = 'F')^2
    }
  }
  M_1 = M_1 * 2/ (T * (T-1))
  kendall_estimator[[1]] = eigen(M_1)$vectors[,1:z[1]]

  M_2 = matrix(0, d[2],d[2])
  for (t1 in 1:(T-1))
  {
    for (t2 in (t1+1):T)
    {
      M_2 = M_2 + t(X[t1,,]@data - X[t2,,]@data) %*% (X[t1,,]@data - X[t2,,]@data) / norm(X[t1,,]@data - X[t2,,]@data, type = 'F')^2
    }
  }
  M_2 = M_2 * 2/ (T * (T-1))
  kendall_estimator[[2]] = eigen(M_2)$vectors[,1:z[1]]


  ## Estimating the number of factors
  eigen_M_1 = eigen(M_1)$values[1:(d[1]/2)]
  ER_seq_1 = exp(-diff(log(eigen_M_1)))
  ER_1 = which.max(ER_seq_1)

  eigen_M_2 = eigen(M_2)$values[1:(d[2]/2)]
  ER_seq_2 = exp(-diff(log(eigen_M_2)))
  ER_2 = which.max(ER_seq_2)




  return(list('A_hat'=kendall_estimator,'r_hat'= c(ER_1,ER_2)))
}


################## He (2021a,b): Huber's loss with weights (RTFA) #########################

robust_tensor_factor = function(  X     # the target 'Tensor' object, where mode-1 is the time mode
                                  , z     # (estimated) number of factors
                                  , proj_N = 30         # number of iterations
                                  , INIT_Q         # the initial estimator, written in a list of K matrices
                                  # , tau = NULL         # threshold controlling Huber's loss, default is NULL, which is data-driven choice to winsorize half of the data
)
  # output : a list of K matrices, where output[[k]] is the mode-k estimated factor loading matrix
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Mean of X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)

  # Initialize the factor loading estimator
  hat_Q_iter = INIT_Q

  # Calculate the iteration step for factor loading matrix
  for (proj_n in 1:proj_N)
  {
    for (k in 1:K)
    {
      # Compute B_k

      # matrix case
      if (K == 2)
      {
        if (k == 1)
        {
          B_k = hat_Q_iter[[2]]
        }

        if (k == 2)
        {
          B_k = hat_Q_iter[[1]]
        }

      }
      # tensor case
      else
      {
        index = (1:K)[-k]
        B_k = hat_Q_iter[[index[1]]]
        for (j in index[-1])
        {
          B_k = kronecker(B_k,hat_Q_iter[[j]])
        }

      }


      # Estimate F_k,t
      hat_F = X_demean
      for (j in (1:K))
        {
          hat_F = rTensor::ttm(tnsr = hat_F, mat = t(hat_Q_iter[[j]]), m = j+1)
      }

      unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])
      unfold_F_k = rTensor::unfold(hat_F,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])

      # compute weight and M_k
      d_k = d[k]
      z_k = z[k]
      A_k = hat_Q_iter[[k]]

      w_k = numeric(T)
      M_k = matrix(0,d_k,d_k)

      er = numeric(T)
      for (t in 1:T)
      {
        X_k_t = unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data
        F_k_t = matrix(unfold_F_k[((t-1)*z_k + 1):(t*z_k)]@data, nrow = z_k)

        er_t = norm(X_k_t - A_k %*% F_k_t %*% t(B_k),type = 'F')
        er[t] = er_t
      }


      tau = median(er)


      for (t in 1:T)
      {
        X_k_t = unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data
        er_t = er[t]

        if (er_t <= tau)
        {
          w_k[t] = 1/2
        }
        else
        {
          w_k[t] = (tau/2) / sqrt(sum(diag(t(X_k_t)%*%X_k_t)) - (sum(diag(t(X_k_t)%*%A_k%*%t(A_k)%*%X_k_t%*%B_k%*%t(B_k)))/prod(d)))
        }

        M_k = M_k + w_k[t] * X_k_t %*% B_k %*% t(B_k) %*% t(X_k_t)

      }


      M_k = M_k / T


      # renew A_k
      hat_Q_iter_k = eigen(M_k)$vectors[,1:z_k]
      hat_Q_iter[[k]] = hat_Q_iter_k


      # renew A_k


      # temp_tensor = X_demean
      # for (j in (1:K)[-k])
      # {
      #   temp_tensor = rTensor::ttm(tnsr = temp_tensor, mat = t(hat_Q_iter[[j]]), m = j+1)
      # }
      #
      # # Perform SVD on the new tensor series
      # HOSVD_k_result = HOSVD_k_ER(temp_tensor, hat_r_iter, k = k)
      # hat_Q_iter_k = HOSVD_k_result[['A_hat']]
      # hat_Q_iter[[k]] = hat_Q_iter_k

    }

  }


  return(hat_Q_iter)
}




################## He (2021a,b): robust iterative eigenvalue-ratio (RTFA-ER) ##########
robust_tensor_factor_ER = function(  X     # the target 'Tensor' object, where mode-1 is the time mode
                                     , proj_N  =30       # number of iterations
                                     , INIT_Q         # the initial estimator, written in a list of K matrices
                                     # , tau = NULL         # threshold controlling Huber's loss, default is NULL, which is data-driven choice to winsorize half of the data
)
  # output: a list of two elements
  #                  output$r_hat : a vector of K elements of estimated number of factors in each mode, where K is the number of modes for the tensor time series
  #                  output$A_hat: a list of K estimated factor loading matrices
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]
  z = floor(d/2)
  
  # Mean of X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)
  
  # Initialize the factor loading estimator
  hat_Q_iter = INIT_Q
  hat_r_iter = z
  
  # Calculate the iteration step for factor loading matrix
  for (proj_n in 1:proj_N)
  {
    for (k in 1:K)
    {
      # Compute B_k
      
      # matrix case
      if (K == 2)
      {
        if (k == 1)
        {
          B_k = hat_Q_iter[[2]]
        }
        
        if (k == 2)
        {
          B_k = hat_Q_iter[[1]]
        }
        
      }
      # tensor case
      else
      {
        index = (1:K)[-k]
        B_k = hat_Q_iter[[index[1]]]
        for (j in index[-1])
        {
          B_k = kronecker(B_k,hat_Q_iter[[j]])
        }
        
      }
      
      
      # Estimate F_k,t
      hat_F = X_demean
      for (j in (1:K))
      {
        hat_F = rTensor::ttm(tnsr = hat_F, mat = t(hat_Q_iter[[j]]), m = j+1)
      }
      
      unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])
      unfold_F_k = rTensor::unfold(hat_F,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])
      
      # compute weight and M_k
      d_k = d[k]
      z_k = hat_r_iter[k]
      A_k = hat_Q_iter[[k]]
      
      w_k = numeric(T)
      M_k = matrix(0,d_k,d_k)
      
      er = numeric(T)
      
      for (t in 1:T)
      {
        X_k_t = unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data
        F_k_t = matrix(unfold_F_k[((t-1)*z_k + 1):(t*z_k)]@data, nrow = z_k)
        
        er_t = norm(X_k_t - A_k %*% F_k_t %*% t(B_k),type = 'F')
        er[t] = er_t
      }
      
      tau = median(er)
      
      for (t in 1:T)
      {
        X_k_t = unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data
        er_t = er[t]
        if (er_t <= tau)
        {
          w_k[t] = 1/2
        }
        else
        {
          w_k[t] = (tau/2) / sqrt(sum(diag(t(X_k_t)%*%X_k_t)) - sum(diag(t(X_k_t)%*%A_k%*%t(A_k)%*%X_k_t%*%B_k%*%t(B_k)))/prod(d))
        }
        
        M_k = M_k + w_k[t] * X_k_t %*% B_k %*% t(B_k) %*% t(X_k_t)
      }
      
      M_k = M_k / T
      
      # renew r_k
      eigen_M_k = eigen(M_k)$values[1:(d_k/2)]
      ER_seq_k = exp(-diff(log(eigen_M_k)))
      ER_k = which.max(ER_seq_k)
      hat_r_iter[k] = ER_k
      
      # renew A_k
      hat_Q_iter_k = eigen(M_k)$vectors[,1:hat_r_iter[k]]
      hat_Q_iter[[k]] = hat_Q_iter_k
      
      
      
      
      
      
    }
    
  }
  
  
  return(list('A_hat' = hat_Q_iter, 'r_hat' = hat_r_iter))
}



###################################### Functions for PE-ER #####################################################################

################################## HOSVD for the k-mode, with eigenvalue-ratio estimator at each step ###########################
HOSVD_k_ER = function(X      # the target 'Tensor' object, where mode-1 is the time mode
                   , z    # (estimated) number of factors
                   , k    # the mode for estimation
)
  # output: a list of two elements
  #                  output$r_hat : a vector of K elements of estimated number of factors in each mode, where K is the number of modes for the tensor time series
  #                  output$A_hat: a list of K estimated factor loading matrices
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)


  # Calculate HOSVD for mode-k
  d_k = d[k]
  z_k = z[k]
  d_minus_k = prod(d) / d_k
  unfold_X_k = rTensor::unfold(X_demean,row_idx = c(k+1, 1), col_idx = c(1:(K+1))[-c(k+1,1)])



  # Calculate the HOSVD tensor

  HOSVD_init = 0
  for (t in 1:T)
  {
    HOSVD_init = HOSVD_init + unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data %*% t(unfold_X_k[((t-1)*d_k + 1):(t*d_k)]@data)
  }

  HOSVD_init = rTensor::as.tensor(HOSVD_init / T)

  # SVD for finding the estimator of factor loadings
  HOSVD_k_estimator = eigen(HOSVD_init@data)$vectors[,1:z_k]

  eigen_M_k = eigen(HOSVD_init@data)$values[1:(d_k/2)]
  ER_seq_k = exp(-diff(log(eigen_M_k)))
  ER_k = which.max(ER_seq_k)

  return(list('A_hat' = HOSVD_k_estimator, 'r_hat' = ER_k))
}


######################################### Function for PE-ER ################################
HOOI_ER = function(  X              # the target 'Tensor' object, where mode-1 is the time mode
                    , proj_N  = 30   # maximum number of iterations
                    , INIT_Q         # the initial estimator, written in a list of K matrices
)
  # output: a list of two elements
  #                  output$r_hat : a vector of K elements of estimated number of factors in each mode, where K is the number of modes for the tensor time series
  #                  output$A_hat: a list of K estimated factor loading matrices
{
  K = length(X@modes) - 1
  d = X@modes[2:(K+1)]
  T = X@modes[1]

  z = floor(d/2)

  # Demean X
  X_mean = apply(X@data, 2:(K+1), mean)
  X_mean_T = aperm(array(X_mean, c(d,T)), c(K+1,1:K))
  X_demean = rTensor::as.tensor(X@data - X_mean_T)

  # Initialize the factor loading estimator
  hat_Q_iter = INIT_Q
  hat_r_iter = z

  # Iterations for HOOI
  for (proj_n in 1:proj_N)
  {
    for (k in 1:K)
    {
      # Calculate the tensor to decompose
      temp_tensor = X_demean
      for (j in (1:K)[-k])
      {
        temp_tensor = rTensor::ttm(tnsr = temp_tensor, mat = t(hat_Q_iter[[j]]), m = j+1)
      }

      # Perform SVD on the new tensor series
      HOSVD_k_result = HOSVD_k_ER(temp_tensor, hat_r_iter, k = k)
      hat_Q_iter_k = HOSVD_k_result[['A_hat']]
      hat_Q_iter[[k]] = hat_Q_iter_k

      hat_r_iter_k = HOSVD_k_result[['r_hat']]
      hat_r_iter[k] = hat_r_iter_k


    }



  }
  return(list('A_hat' = hat_Q_iter, 'r_hat' = hat_r_iter))
}









