##################################### This script is for generating data for simulation #############################
##### It generates data under different settings and dimensions and save it for simulations

library(MASS)
library(pracma)
library(rTensor)
library(TensorPreAve)

library(doSNOW)
library(parallel)

# ncore = detectCores()    # The number of cores to use for parallel computing
ncore = 6



### Change settings (i) to (v) for data generation under different dimensions

# (i)
K = 2                     # The number of modes for the tensor time series
T = 100                   # Length of time series
d = c(40,40)              # Dimensions of each mode of the tensor

# # (ii)
# K = 2
# T = 200
# d = c(80,80)
#
# # (iii)
# K = 3
# T = 200
# d = c(15,15,15)
#
# # (iv)
# K = 3
# T = 200
# d = c(25,25,25)
#
# # (v)
# K = 4
# T = 200
# d = c(15,15,15,15)


r = rep(2,K)                # Rank of core tensors
re = rep(2,K)               # Rank of the cross-sectional common error core tensors


## We run parallel computing to generate data from all 12 profiles of each dimension
eta_list = list(rep(list(c(0,0)),K),                      # Setting (I)
                rep(list(c(0,0.2)),K),                    # Setting (II)
                rep(list(c(0.1,0.2)),K))                  # Setting (III)

u_list <- list(rep(list(c(-2,2)),K),                      # Sub-setting (a)
               rep(list(c(0,0,2)),K))                     # Sub-setting (b)

heavy_tail_list = c(rep(FALSE,6),rep(TRUE,6))


eta_total <- rep(eta_list, 4)
u_total <- rep(u_list,6)


cl <- makeCluster(ncore)
registerDoSNOW(cl)
pb <- txtProgressBar(max = 12, style = 3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress = progress)
t111 <- Sys.time()
# start parallel computing
sim11 <- foreach(j = 1:12, .options.snow = opts) %dopar% {

  eta <- eta_total[[j]]
  u <- u_total[[j]]
  heavy_tail = heavy_tail_list[j]

  Data_record = list()

  total_start_time = Sys.time()

  set.seed(2023)
  N = 500                # number of repetitions
  for (n in 1:N)
  {
    print (n)
    start_time = Sys.time()

    if (heavy_tail)
    {
      Data_test = TensorPreAve::tensor_data_gen(K, T, d, r, re, eta, u, heavy_tailed = TRUE, t_df = 3)
    }
    else
    {
      Data_test = TensorPreAve::tensor_data_gen(K,T,d,r,re,eta,u)
    }
    Data_record[[n]] = Data_test

    end_time = Sys.time()
    print(end_time - start_time)
  }

  total_end_time = Sys.time()
  print(total_end_time - total_start_time)

  ## Save the data

  para_list = list(
    'K' = K,
    'T' = T,
    'd' = d,
    'r' = r,
    're' = re,
    'eta' = eta,
    'u' = u)

  file_name = paste(names(para_list),para_list,sep="=",collapse="_")

  # heavy tailed cases
  if (heavy_tail)
  {
    file_name = paste(file_name,'t3',sep = '_')
  }

  data_file_name = paste(file_name, 'Data',sep = '_')

  saveRDS(Data_record, file = paste(data_file_name,'.RData',sep = ''))


}
t112 <- Sys.time()
close(pb)
# stop cluster
stopCluster(cl)
print(t112-t111)





