## For simulation experiments:

Step 1 (Data Generation): Run parallel_data_generation.R to generate data under different simulation profiles and dimensions (using parallel computing for each profile under the same dimension). The generated data, one .RData file for each profile and dimension, will be stored in the same folder as the codes. The name of the .RData file contains parameters used to generate the data.
 
Step 2 (Estimation): Run parallel_estimation.R to read the generated data and estimate the factor loading spaces and the rank of the core tensors (using parallel computing for each profile under the same dimension). The results (which include estimation errors of factor loading spaces, estimated rank of core tensors, computational time) will be stored into two csv files for each profile and dimension, _Est.csv for factor loading estimations and _Rank.csv for rank estimations.

Step 3 (Analysis and Plot): Run analysis_plot.R to produce figures of boxplots and tables based on the simulation results stored in the csv files. Different estimation methods will be compared in the boxplots.



## For real data analysis:

# NYC taxi traffic:

Step 1 (Data Processing): Run NYC_data_processing.R to clean and process the raw data of NYC taxi traffic from online source: https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page. Two tensor time series, one for business day and one for non-business day, will be stored as two .RData files for each year. 

Step 2 (Data Analysis): Run NYC_data_analysis.R to read the NYC taxi traffic data after pre-processing, and estimate the tensor factor models accordingly.

# Fama-French profolios (in supplement of the revised paper):

Run Fama_French_data_analysis.R to estimate and analyze the tensor factor models on Fama-French portfolio data. The data needed for analysis are already pre-processed and included as three csv files: 100_Portfolios_ME_OP_10x10.csv, ValueWeightedM-OP.csv and NYSEreturn.csv.



## Note:

(i) The estimation methods proposed by our paper are written into an R package TensorPreAve published on CRAN. Detailed explanations of the use of functions can be found in the vignettes and manual of the package, as well as the revised paper.

(ii) supporting_functions.R contains other functions needed for simulation and real data analysis, including functions of other state-of-the-art estimation methods for comparision, such as iTIPUP/PE/RTFA/alpha-PCA/MRTS.

